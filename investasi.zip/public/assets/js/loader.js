$(function() {
    $('.btn-submit').on('click', function() {
        $('.btn-submit span').hide()
        $('.loading-spinner').show()
    })
})