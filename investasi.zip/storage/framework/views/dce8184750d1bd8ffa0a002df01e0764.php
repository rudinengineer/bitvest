
<?php $__env->startSection('container'); ?>
<div class="mt-16">
    <?php if($products->count()): ?>
        <div class="w-full grid grid-cols-1 ss:grid-cols-2 md:grid-cols-3 px-4 py-2 sm:px-2">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('components.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="p-6 w-full flex justify-center">
            <h1 class="text-xs sm:text-base text-center">Data tidak ditemukan.</h1>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/pages/index.blade.php ENDPATH**/ ?>