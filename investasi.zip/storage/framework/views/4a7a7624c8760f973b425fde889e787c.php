
<?php $__env->startSection('container'); ?>
<div class="mt-16 p-4 sm:grid grid-cols-2">
    <div class="hidden sm:flex">
        <img src="<?php echo e(asset('/assets/images/account.png')); ?>" alt="Account Image" class="w-full h-full">
    </div>
    <div class="sm:p-10">
        <h1 class="text-2xl font-bold text-primary text-center">Pengaturan Akun</h1>
        <form action="/profile/setting" method="post" class="mt-4">
            <?php echo method_field('post'); ?>
            <?php echo csrf_field(); ?>
            <div>
                <div>
                    <label for="email">Email address</label>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="email" name="email" id="email" placeholder="example@gmail.com" autocomplete="off" class="w-full outline-none px-4 py-3 rounded-md border-[1px] border-slate-300 transition duration-300 ease-in-out focus:border-primary" value="<?php echo e(old('email') ? old('email') : auth()->user()->email); ?>">
            </div>
            <div class="mt-2">
                <div>
                    <label for="old_password">Password lama</label>
                </div>
                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="password" name="old_password" id="old_password" placeholder="***" autocomplete="off" class="w-full outline-none px-4 py-3 rounded-md border-[1px] border-slate-300 transition duration-300 ease-in-out focus:border-primary">
            </div>
            <div class="mt-2">
                <div>
                    <label for="new_password">Password baru</label>
                </div>
                <input type="password" name="new_password" id="new_password" placeholder="***" autocomplete="off" class="w-full outline-none px-4 py-3 rounded-md border-[1px] border-slate-300 transition duration-300 ease-in-out focus:border-primary">
            </div>
            <div class="mt-4">
                <button type="submit" class="btn-submit w-full flex justify-center items-center py-3 bg-primary rounded-md font-bold text-light transition ease-in-out hover:bg-opacity-90"><span>Simpan</span><?php echo $__env->make('components.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
            </div>
        </form>
    </div>
</div>
<script src="<?php echo e(asset('/assets/js/loader.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/users/setting.blade.php ENDPATH**/ ?>