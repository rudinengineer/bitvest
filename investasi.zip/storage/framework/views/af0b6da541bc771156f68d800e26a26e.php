<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="<?php echo e(asset('/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/navbar.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/script.js')); ?>"></script>
</head>
<body>
    <?php echo $__env->yieldContent('container'); ?>

    <?php if(session()->has('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: "<?php echo e(session('success')); ?>",
                timer: 2000
            })
        </script>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: "<?php echo e(session('error')); ?>",
                timer: 2000
            })
        </script>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/layouts/default.blade.php ENDPATH**/ ?>