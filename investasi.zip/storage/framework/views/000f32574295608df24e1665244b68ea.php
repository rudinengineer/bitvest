<?php $__env->startSection('container'); ?>
<div id="content">

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 text-gray-800">Pengaturan Website</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <form action="/admin/settings" enctype="multipart/form-data" method="post">
                    <?php echo method_field('post'); ?>
                    <?php echo csrf_field(); ?>
                    <div>
                        <div class="form-group">
                            <label for="referal_reward">Hadiah Dari Referal</label>
                            <?php $__errorArgs = ['referal_reward'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" class="form-control" id="referal_reward" placeholder="Masukkan Hadiah Dari Referal" name="referal_reward" autocomplete="off" value="<?php echo e(old('referal_reward') ? old('referal_reward') : $setting->referal_reward); ?>" required autofocus>
                        </div>
                        <div class="form-group">
                            <label for="minimal_wd">Minimal Withdraw</label>
                            <?php $__errorArgs = ['minimal_wd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" class="form-control" id="minimal_wd" placeholder="Masukkan Minimal Withdraw" name="minimal_wd" autocomplete="off" value="<?php echo e(old('minimal_wd') ? old('minimal_wd') : $setting->minimal_wd); ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/admin/settings.blade.php ENDPATH**/ ?>