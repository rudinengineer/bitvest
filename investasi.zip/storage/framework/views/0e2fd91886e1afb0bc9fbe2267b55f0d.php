
<?php $__env->startSection('container'); ?>
<div class="mt-16 sm:hidden">
    <form action="/search" method="get" class="w-full grid grid-cols-[3fr__1fr] gap-1 items-center p-4">
        <div>
            <input type="text" name="keyword" id="" class="w-full px-4 py-3 outline-none rounded-md border-[1px] border-slate-300 transition duration-300 ease-in-out focus:border-primary" autocomplete="off">
        </div>
        <button type="submit" class="w-full py-3 rounded-md bg-primary font-bold text-light">Search</button>
    </form>
    <?php if($products->count()): ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="px-4">
        <?php echo $__env->make('components.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="w-full flex justify-center">
            <h1 class="text-xs text-center">Data tidak ditemukan.</h1>
        </div>
    <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/pages/search.blade.php ENDPATH**/ ?>