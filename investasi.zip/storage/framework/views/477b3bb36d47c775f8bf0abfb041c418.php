<nav class="w-full fixed bottom-0 left-0 bg-light shadow-sm border-t-[1px] border-slate-300 flex sm:hidden justify-around items-center px-2 z-[50]">
    <a href="/" class="<?php if(Request::is('/')): ?>text-primary border-t-[1px] border-primary <?php endif; ?> py-4">
        <div class="flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-7 h-7">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                <title>beranda</title>
            </svg>
            <h1 class="text-xs font-semibold">Beranda</h1>
        </div>
    </a>
    <a href="/search" class="<?php if(Request::is('search')): ?>text-primary border-t-[1px] border-primary <?php endif; ?> py-4">
        <div class="flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-7 h-7">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                <title>search</title>
            </svg>
            <h1 class="text-xs font-semibold">Explore</h1>
        </div>
    </a>
    <a href="/referal" class="<?php if(Request::is('referal')): ?>text-primary border-t-[1px] border-primary <?php endif; ?> py-4">
        <div class="flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-7 h-7">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H5.25a1.5 1.5 0 01-1.5-1.5v-8.25M12 4.875A2.625 2.625 0 109.375 7.5H12m0-2.625V7.5m0-2.625A2.625 2.625 0 1114.625 7.5H12m0 0V21m-8.625-9.75h18c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125h-18c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                <title>referal</title>
            </svg>
            <h1 class="text-xs font-semibold">Hadiah</h1>
        </div>
    </a>
    <a href="/saldo" class="<?php if(Request::is('saldo*') || Request::is('transaction*')): ?>text-primary border-t-[1px] border-primary <?php endif; ?> py-4">
        <div class="flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-7 h-7">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" />
                <title>penghasilan</title>
            </svg>
            <h1 class="text-xs font-semibold">Saldo</h1>
        </div>
    </a>
    <a href="<?php if(auth()->user()): ?>/profile <?php else: ?> /signin <?php endif; ?>" class="<?php if(Request::is('profile*')): ?>text-primary border-t-[1px] border-primary <?php endif; ?> py-4">
        <div class="flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-7 h-7">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
                <title>account</title>
            </svg>
            <h1 class="text-xs font-semibold">Account</h1>
        </div>
    </a>
</nav><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/components/bottombar.blade.php ENDPATH**/ ?>