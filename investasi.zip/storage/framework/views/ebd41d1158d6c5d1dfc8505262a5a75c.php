
<?php $__env->startSection('container'); ?>
<div class="mt-16 p-4 sm:grid grid-cols-2">
    <div class="hidden sm:flex">
        <img src="<?php echo e(asset('/assets/images/pay.png')); ?>" alt="Payment Image" class="w-full h-full">
    </div>
    <div class="sm:px-10 sm:py-5">
        <?php echo $__env->make('components.transaction_history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/transaction/history.blade.php ENDPATH**/ ?>