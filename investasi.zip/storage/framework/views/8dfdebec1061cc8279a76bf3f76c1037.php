<?php $__env->startSection('container'); ?>
<div id="content">

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 text-gray-800">Data Transaksi Deposit</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>UUID</th>
                                <th>Username</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                                <th>#</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>UUID</th>
                                <th>Username</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                                <th>#</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php if($deposits->count()): ?>
                            <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$i); ?></td>
                                    <td><?php echo e($deposit->user->username); ?></td>
                                    <td>Rp <?php echo e(number_format($deposit->total, 0, '.', '.')); ?></td>
                                    <td class="<?php echo e($deposit->status === 'paid' ? 'text-primary' : ($deposit->status === 'unpaid' ? 'text-warning' : 'text-danger')); ?>"><?php echo e($deposit->status === 'paid' ? 'Lunas' : ($deposit->status === 'unpaid' ? 'Dalam Proses' : 'Batal')); ?></td>
                                    <td><?php echo e($deposit->created_at->format('d-m-Y H:i:s')); ?></td>
                                    <td>
                                        <button class="btn btn-warning" data-toggle="modal" data-target="#editModal-<?php echo e($deposit->uuid); ?>">Detail</button>
                                        
                                        <div class="modal fade" id="editModal-<?php echo e($deposit->uuid); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Transaksi</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div>UUID : <?php echo e($deposit->uuid); ?></div>
                                                        <div>KODE : <?php echo e($deposit->code); ?></div>
                                                        <div>USERNAME : <?php echo e($deposit->user->username); ?></div>
                                                        <div>EMAIl : <?php echo e($deposit->user->email); ?></div>
                                                        <?php if($deposit->user->phone): ?>
                                                            <div>NO.HP : <?php echo e($deposit->user->phone); ?></div>
                                                        <?php endif; ?>
                                                        <?php if($deposit->product): ?>
                                                            <div>NAMA PRODUK : <?php echo e($deposit->product->name); ?></div>
                                                        <?php endif; ?>
                                                        <?php if($deposit->credit_card): ?>
                                                            <div>NOMOR DANA : <?php echo e($deposit->credit_card); ?></div>
                                                        <?php endif; ?>
                                                        <div>TOTAL : Rp<?php echo e(number_format($deposit->total, 0, '.', '.')); ?></div>
                                                        <div>BIAYA ADMIN : Rp<?php echo e(number_format($deposit->biaya_admin, 0, '.', '.')); ?></div>
                                                        <div>SUBTOTAL : Rp<?php echo e(number_format($deposit->subtotal, 0, '.', '.')); ?></div>
                                                        <div>TIPE : <?php echo e($deposit->type); ?></div>
                                                        <div>STATUS : <?php echo e($deposit->status); ?></div>
                                                        <div>Tanggal : <?php echo e($deposit->created_at->format('d-m-Y H:i:s')); ?></div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </td>
                                    <td>
                                    <?php if($deposit->status === "pending"): ?>
                                        <button class="btn btn-success" onclick="question('Pembayaran akan dilunaskan!', '/transaction/<?php echo e($deposit->uuid); ?>/paid')">Selesaikan</button>
                                        <button class="btn btn-danger" onclick="question('Pembayaran akan dibatalkan!', '/transaction/<?php echo e($deposit->uuid); ?>/unpaid')">Batalkan</button>
                                    <?php else: ?>
                                        <button class="btn btn-danger" onclick="question('Data akan terhapus!', '/transaction/<?php echo e($deposit->uuid); ?>/delete')">Hapus</button>
                                    <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">Data masih kosong.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/admin/deposit.blade.php ENDPATH**/ ?>