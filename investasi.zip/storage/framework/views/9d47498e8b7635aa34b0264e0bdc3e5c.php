<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(env('APP_NAME')); ?> 2023</span>
        </div>
    </div>
</footer><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/components/admin/footer.blade.php ENDPATH**/ ?>