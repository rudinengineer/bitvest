
<?php $__env->startSection('container'); ?>
<div class="mt-16">
    <h1>Hello World!</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/index.blade.php ENDPATH**/ ?>