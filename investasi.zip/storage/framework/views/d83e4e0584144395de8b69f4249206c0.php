<div>
    <h1 class="text-base font-bold sm:text-xl">Riwayat Transaksi</h1>
    <div>
        <?php if($transactions->count()): ?>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a <?php if($transaction->type === "deposit" && $transaction->status === "pending"): ?>href="/transaction/<?php echo e($transaction->uuid); ?>" <?php endif; ?> class="mt-2 w-full flex justify-between items-center transition ease-in-out hover:bg-slate-100 p-2">
                <div>
                    <div class="flex gap-1.5">
                        <h1 class="text-base font-bold">+<?php echo e(number_format($transaction->total, 0, '.', '.')); ?></h1>
                        <h1 class="text-xs rounded-md font-semibold <?php echo e($transaction->status === 'pending' ? 'text-yellow-500' : ($transaction->status === 'paid' ? 'text-green-500' : 'text-red-500')); ?>"><?php echo e($transaction->status); ?></h1>
                    </div>
                    <h1 class="text-xs"><?php echo e($transaction->created_at->format('Y-m-d')); ?></h1>
                </div>
                <h1 class="text-xs px-3 py-1.5 <?php echo e($transaction->type === 'deposit' ? 'bg-primary' : ($transaction->type === 'withdraw' ? 'bg-red-500' : 'bg-yellow-500')); ?> rounded-md text-light"><?php echo e($transaction->type); ?></h1>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h1 class="mt-2 text-xs sm:text-sm text-center">anda belum melakukan transaksi apapun.</h1>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\jasa\investasi\resources\views/components/transaction_history.blade.php ENDPATH**/ ?>